// Environment code for project JasonSample

import jason.asSyntax.Literal;
import jason.asSyntax.Structure;

import java.util.logging.Logger;

public class Room extends jason.environment.Environment {

    private Logger logger = Logger.getLogger("JasonSample."+Room.class.getName());

    /** Called before the MAS execution with the args informed in .mas2j */
    @Override
    public void init(String[] args) {
        addPercept(Literal.parseLiteral("percept(demo)"));
    }

    @Override
    public boolean executeAction(String ag, Structure action) {
        logger.info("executing: "+action+", but not implemented!");
        return true;
    }

    /** Called before the end of MAS execution */
    @Override
    public void stop() {
    }
}
